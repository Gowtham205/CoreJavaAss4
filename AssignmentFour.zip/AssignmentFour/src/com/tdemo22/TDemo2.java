package com.tdemo22;

import com.tdemo11.TDemo1;

public class TDemo2 {
	public void met2() throws NullPointerException, Exception {
		try {
			TDemo1 td = new TDemo1();
			td.met1();
		} catch (Exception ep) {
			System.out.println("Exception catching..........");
			throw ep;
		} finally {
			System.out.println("finally  met2() in TDemo2");
		}
		System.out.println("out side of finally met2() in TDemo2");
	}
}