package assignmentFour;

import java.util.Comparator;
import java.util.Set;
import java.util.TreeMap;

//b) Now make changes such that TreeMap sorts state name in descending order
//str2.compareTo(str1)

public class FirstProbB {
	public static void main(String[] args) {
		
		TreeMap<String, String> tMap = new TreeMap<String, String>(new MyComparator());
		tMap.put("Karnataka", "Bangalore");
		tMap.put("AndhraPradesh", "Amaravathi");
		tMap.put("Maharastra","Mumbai");
		tMap.put("Telangana", "Hyderabad");
	
		Set<String> keys = tMap.keySet();
		
		for(String key : keys) {
			String val = tMap.get(key);
			System.out.println(key+" : "+val);
		}		
	}
}
class MyComparator implements Comparator<String>{

	@Override
	public int compare(String o1, String o2) {
		return o1.compareTo(o2)*-1;
	}
	
}
