package assignmentFour;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map.Entry;

class Cities {
	private String name;

	public Cities(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "name=" + name;
	}

}

public class FourthProb {

	public static void main(String[] args) {

//		#4. Create a Nested Collection, in a HashMap, Key is String which is state name, and value is LinkedList 
//		of City names in that specific state. Iterate thru and display each State with various Cities in that State. 

		HashMap<String, LinkedList<Cities>> map = new HashMap<String, LinkedList<Cities>>();

		LinkedList<Cities> list1 = new LinkedList<Cities>();
		list1.add(new Cities("Nellore"));
		list1.add(new Cities("Vizag"));
		list1.add(new Cities("Vijayawada"));
		list1.add(new Cities("Tirupathi"));

		LinkedList<Cities> list2 = new LinkedList<Cities>();
		list2.add(new Cities("Chennai"));
		list2.add(new Cities("Kanchi"));
		list2.add(new Cities("Madurai"));
		list2.add(new Cities("Coimbatore"));

		map.put("AP", list1);
		map.put("TN", list2);

		for (Entry<String, LinkedList<Cities>> value : map.entrySet()) {
			System.out.println(value.getKey() + " : " + value.getValue());
		}

	}

}
