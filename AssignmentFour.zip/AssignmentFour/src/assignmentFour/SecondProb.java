package assignmentFour;

import java.util.Set;
import java.util.TreeMap;


//#2. In above example, Use TreeMap, with key as State name, Value as object of Capital 
//city(with data members, name, population, desc). Iterate and display Key & Value.

public class SecondProb {
	public static void main(String[] args) {
		
		TreeMap<String, City> tMap = new TreeMap<String, City>();
		tMap.put("AndhraPradesh", new City("Vizag", 2394243, "city of Beaches"));
		tMap.put("Karnataka", new City("Bangalore",6534423,"City of weather"));
		tMap.put("Maharastra",new City("Mumbai",9987356,"Financial city of india"));
		tMap.put("Telangana", new City("Hyderabad",7436721,"IT Sector hub"));
		
		Set<String> keys = tMap.keySet();
		for(String k : keys) {
			System.out.println("Capital is : "+k+" and city is : "+tMap.get(k));
		}
	}
}
