package assignmentFour;

import java.util.TreeSet;

//#3. Create TreeSet with Strings, use Stream and convert each string into capital case, print the result

public class ThirdProb {
	public static void main(String[] args) {
		
		TreeSet<String> countries = new TreeSet<String>();
		
		countries.add("india");
		countries.add("usa");
		countries.add("russia");
		countries.add("south korea");
		countries.add("egypt");
		
		countries.stream().forEach(val -> { System.out.println(val.toUpperCase());} );
		
	}
}
