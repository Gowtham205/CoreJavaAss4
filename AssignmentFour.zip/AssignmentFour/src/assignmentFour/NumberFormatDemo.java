package assignmentFour;

import com.tdemo22.TDemo2;

public class NumberFormatDemo {
	public static void main(String args[]) {
		try {
			TDemo2 td2 = new TDemo2();
			td2.met2();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			System.out.println("dsdsfds");
		}
	}
}
