package assignmentFour;

public class City {
	private String cityName;
	private long population;
	private String desc;

	public City(String cityName, long population, String desc) {
		this.cityName = cityName;
		this.population = population;
		this.desc = desc;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public long getPopulation() {
		return population;
	}

	public void setPopulation(long population) {
		this.population = population;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	@Override
	public String toString() {
		return "City [cityName=" + cityName + ", population=" + population + ", desc=" + desc + "]";
	}
}
